/*
 * Project name:
     UART (UART library Demonstration)
 * Copyright:
     (c) MikroElektronika
 * Description:
     This is a simple demonstration of PWM library, which is being used for
     control of the PIC's CCP module. The changes can be monitored on the CCP
     output pins (RC4 and RC5).
 * Test configuration:
     MCU:             PIC16F18345
                      http://ww1.microchip.com/downloads/en/DeviceDoc/41364B.pdf
     Dev.Board:       EasyPIC7
                      http://www.mikroe.com/easypic/
     Oscillator:      HS, 08.0000 MHz
     Ext. Modules:    -
     SW:              mikroC PRO for PIC
                      http://www.mikroe.com/mikroc/pic/
 * NOTES:
     - To configure fuses do the following
       - Click Default,
       - Change MCU Clock frequency to 8 MHZ
       - For OScillator Mode selection bit, set to HS Above 4MHZ
       - For PPS Lock, set to 'can be set and cleared repeaedly' . . .
*/

char output[10];

void InitMain() {
  ANSELA = 0;
  ANSELC = 0;
  ANSELB = 0;

  SLRCONC = 0;

  Unlock_IOLOCK();
     TRISB7_bit = 0;
     TRISB5_bit = 1;
     //PPS_Mapping_NoLock(RB7,_OUTPUT, _TX_CK);
     RB7PPS = 0b10100;   //TX
     RB5PPS = 0b01101;   //RX
  Lock_IOLOCK();

  UART1_Remappable_Init(9600);
}

void main() {

  InitMain();

  while (1) {
   if (UART1_Remappable_Data_Ready() == 1) {          // if data is received
    UART1_Remappable_Read_Text(output, "OK", 10);    // reads text until 'OK' is found (maximum 10 characters)
    UART1_Remappable_Write_Text(output);             // sends back text
   }
  }
}